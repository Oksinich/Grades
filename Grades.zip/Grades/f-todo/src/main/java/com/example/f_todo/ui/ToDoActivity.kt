package com.example.f_todo.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import com.example.f_todo.BuildConfig
import com.example.f_todo.R

open class ToDoActivity : Activity() {

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.to_do_activity)

		val importantButton = findViewById<Button>(R.id.to_do_button)

		importantButton.setOnClickListener {
			val addressUri: Uri = Uri.parse(BuildConfig.IMPORTANT_URL)
			val openLinkIntent = Intent(Intent.ACTION_VIEW, addressUri)
			startActivity(openLinkIntent)
		}
	}
}